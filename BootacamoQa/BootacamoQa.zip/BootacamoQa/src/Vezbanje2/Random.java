package Vezbanje2;

public class Random {
    public static double nextDouble() {
        return Math.round(Math.random() * (2 - 1) + 1);
    }
}

package PasteBinVIII;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        Grad pariz = new Grad("Pariz",200 ,"Francuska");
        Osoba vodja = new Osoba("Petar", "Petrovic");
        Osoba vodja1 = new Osoba("P", "Petr");
        Osoba vodja2 = new Osoba("Per", "Petra");
        Osoba vodja3 = new Osoba("Pera", "Petraov");
        Automobil bmw = new Automobil("BMW", "520", 1245);
        ArrayList<Osoba> o = new ArrayList<>();
        o.add(vodja);
        o.add(vodja1);
        o.add(vodja2);
        o.add(vodja3);
        Putovanje a = new Putovanje(pariz, vodja,bmw, -5, o);

        System.out.println(a);
    }
}

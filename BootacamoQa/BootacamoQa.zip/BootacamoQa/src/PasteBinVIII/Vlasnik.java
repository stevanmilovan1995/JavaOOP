package PasteBinVIII;

public class Vlasnik extends Osoba{
    public Vlasnik(String ime, String prezime) {
        super(ime, prezime);
    }

    @Override
    public String getIme() {
        return super.getIme();
    }

    @Override
    public void setIme(String ime) {
        super.setIme(ime);
    }

    @Override
    public String getPrezime() {
        return super.getPrezime();
    }

    @Override
    public void setPrezime(String prezime) {
        super.setPrezime(prezime);
    }
}
